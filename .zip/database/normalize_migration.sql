-- =============================================================
-- COC-LMS Normalization Migration
-- Apply to existing cit_lms database to bring it to 3NF.
-- =============================================================
-- Run order matters — follow each section in sequence.
-- =============================================================

SET FOREIGN_KEY_CHECKS = 0;

-- -------------------------------------------------------------
-- 1. ADD MISSING COLUMN: users.token_version
--    Used by jwt.php and AuthAPI.php for JWT revocation but
--    not present in the original schema.
--    (Skip if the column already exists — safe to re-run)
-- -------------------------------------------------------------
SET @col_exists = (
  SELECT COUNT(*) FROM information_schema.COLUMNS
  WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = 'users' AND COLUMN_NAME = 'token_version'
);
SET @sql = IF(@col_exists = 0,
  'ALTER TABLE `users` ADD COLUMN `token_version` INT NOT NULL DEFAULT 0 AFTER `status`',
  'SELECT 1'
);
PREPARE _stmt FROM @sql; EXECUTE _stmt; DEALLOCATE PREPARE _stmt;

-- -------------------------------------------------------------
-- 2. REMOVE REDUNDANT COLUMN: curriculum.course_code
--    Violates 2NF — depends only on course_id, not on the
--    composite key (program_id, course_id).
--    The value is always equal to subject.subject_code via the
--    course_id FK. Fetch it with a JOIN instead.
-- -------------------------------------------------------------
ALTER TABLE `curriculum`
  DROP COLUMN `course_code`;

-- -------------------------------------------------------------
-- 3. REMOVE DUPLICATE UNIQUE KEY: section.uq_enrollment_code
--    Two identical unique constraints on the same column.
--    Keep the first one (enrollment_code), drop the alias.
-- -------------------------------------------------------------
ALTER TABLE `section`
  DROP KEY `uq_enrollment_code`;

-- -------------------------------------------------------------
-- 4. REMOVE REDUNDANT COLUMN: announcement.is_published
--    Violates 3NF — status enum('draft','published','archived')
--    already encodes published state. The two columns can
--    silently diverge. No API SELECT/INSERT/UPDATE uses
--    is_published; all code gates on status.
-- -------------------------------------------------------------
ALTER TABLE `announcement`
  DROP KEY `idx_announcement_published`,
  DROP COLUMN `is_published`;

-- -------------------------------------------------------------
-- 5. NORMALIZE: subject.pre_requisite → subject_prerequisite
--    pre_requisite varchar(100) stores a subject_code string
--    instead of a FK reference — a 3NF violation (transitive
--    dependency: subject → pre_requisite code → subject row).
-- -------------------------------------------------------------

-- 5a. Create the junction table
CREATE TABLE IF NOT EXISTS `subject_prerequisite` (
  `subject_id`              INT NOT NULL,
  `prerequisite_subject_id` INT NOT NULL,
  PRIMARY KEY (`subject_id`, `prerequisite_subject_id`),
  KEY `idx_sp_prereq` (`prerequisite_subject_id`),
  CONSTRAINT `fk_sp_subject` FOREIGN KEY (`subject_id`)
    REFERENCES `subject` (`subject_id`) ON DELETE CASCADE,
  CONSTRAINT `fk_sp_prereq` FOREIGN KEY (`prerequisite_subject_id`)
    REFERENCES `subject` (`subject_id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- 5b. Migrate existing data (match pre_requisite string to subject_code)
INSERT IGNORE INTO `subject_prerequisite` (`subject_id`, `prerequisite_subject_id`)
SELECT s.`subject_id`, prereq.`subject_id`
FROM   `subject` s
JOIN   `subject` prereq ON prereq.`subject_code` = s.`pre_requisite`
WHERE  s.`pre_requisite` IS NOT NULL
  AND  s.`pre_requisite` <> '';

-- 5c. Drop the de-normalized column
ALTER TABLE `subject`
  DROP COLUMN `pre_requisite`;

-- -------------------------------------------------------------
-- 6. ADD MISSING FK CONSTRAINTS
--    Several FK columns exist with only indexes, no enforcement.
-- -------------------------------------------------------------

-- curriculum.course_id references subject.subject_id
ALTER TABLE `curriculum`
  ADD CONSTRAINT `fk_curriculum_course`
    FOREIGN KEY (`course_id`) REFERENCES `subject` (`subject_id`) ON DELETE CASCADE,
  ADD CONSTRAINT `fk_curriculum_semester`
    FOREIGN KEY (`semester_id`) REFERENCES `semester` (`semester_id`) ON DELETE SET NULL;

-- question_option.quiz_question_id references quiz_questions.quiz_questions_id
-- Clean up any orphaned options first
DELETE FROM `question_option`
WHERE `quiz_question_id` NOT IN (SELECT `quiz_questions_id` FROM `quiz_questions`);

ALTER TABLE `question_option`
  ADD CONSTRAINT `fk_qopt_quiz_question`
    FOREIGN KEY (`quiz_question_id`) REFERENCES `quiz_questions` (`quiz_questions_id`) ON DELETE CASCADE;

-- student_quiz_answers FKs (columns exist but constraints are missing)
-- Clean up orphaned answers first
DELETE FROM `student_quiz_answers`
WHERE `attempt_id` NOT IN (SELECT `attempt_id` FROM `student_quiz_attempts`);

ALTER TABLE `student_quiz_answers`
  ADD CONSTRAINT `fk_sqa_attempt`
    FOREIGN KEY (`attempt_id`) REFERENCES `student_quiz_attempts` (`attempt_id`) ON DELETE CASCADE,
  ADD CONSTRAINT `fk_sqa_quiz`
    FOREIGN KEY (`quiz_id`) REFERENCES `quiz` (`quiz_id`) ON DELETE CASCADE,
  ADD CONSTRAINT `fk_sqa_student`
    FOREIGN KEY (`user_student_id`) REFERENCES `users` (`users_id`) ON DELETE CASCADE,
  ADD CONSTRAINT `fk_sqa_option`
    FOREIGN KEY (`selected_option_id`) REFERENCES `question_option` (`option_id`) ON DELETE SET NULL;

-- subject_offered.user_teacher_id
ALTER TABLE `subject_offered`
  ADD CONSTRAINT `fk_so_teacher`
    FOREIGN KEY (`user_teacher_id`) REFERENCES `users` (`users_id`) ON DELETE SET NULL;

-- quiz subject and teacher
ALTER TABLE `quiz`
  ADD CONSTRAINT `fk_quiz_subject`
    FOREIGN KEY (`subject_id`) REFERENCES `subject` (`subject_id`) ON DELETE CASCADE,
  ADD CONSTRAINT `fk_quiz_teacher`
    FOREIGN KEY (`user_teacher_id`) REFERENCES `users` (`users_id`) ON DELETE CASCADE;

SET FOREIGN_KEY_CHECKS = 1;

-- =============================================================
-- What was intentionally kept (documented denormalizations):
--
--   student_progress.subject_id
--     Transitive via lessons_id → lessons.subject_id, but kept
--     as an indexed denormalization because DashboardAPI filters
--     large result sets with WHERE sp.subject_id IN (...).
--
--   student_quiz_answers.quiz_id + user_student_id
--     Transitive via attempt_id → student_quiz_attempts, but
--     kept for analytics queries that need indexed access on
--     quiz_id/user_student_id without joining attempts.
--
--   subject.semester (int 1/2/3)
--     NOT the same as semester_id (FK to specific semester row).
--     semester int = which sem of the school year the subject
--     belongs to in the curriculum (curriculum position).
--     semester_id = specific offered semester with year+dates.
--
--   department_program junction table
--     Inconsistent with program.department_id FK (both exist),
--     but too many API files depend on the junction table for
--     a safe drop in this migration.
-- =============================================================
