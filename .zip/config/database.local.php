<?php
// Skip if connected to a non-local DB host (i.e. we're on a live server)
if (!in_array(strtolower($dbHost ?? ''), ['127.0.0.1', 'localhost', ''], true)) return;

$dbName = 'cit_lms';
